EVENT GotoForm1(EventPtr event)
{
   // Return "false" to execute default message handling
   Form2.Back(); 
}