#define MAX 51
Char *Sentences(UInt16 which)
{
 static Char *Sentence[]={ 
  "Der der ich bin,gr��t traurig den,der ich sein m�chte.", 
  "Der Idealismus w�chst,mit der Entfernung,vom Problem.", 
  "Fernsehen unterh�lt die Leute,indem es verhindert,da� sie sich unterhalten.", 
  "Ein Plan,der sich nicht �ndern l�sst,ist ein schlechter Plan.", 
  "Fehler die wir einsehen,k�nnen nicht mehr,ins Auge gehen.",
  "Der Vorteil der Klugheit,besteht darin,da� man sich dumm,stellen kann.,Das Gegenteil ist,schon schwieriger.", 
  "Eine Familie ist ein,steuerlich beg�nstigter,Kleinbetrieb,zur Herstellung von,Steuerzahlern.",
  "Tr�ume nicht dein Leben,lebe deinen Traum.", 
  "Wer keinen Mut,zum Tr�umen hat,hat keine Kraft,zum K�mpfen. ", 
  "In Dir muss brennen,was Du in anderen,entz�nden m�chtest.", 
  "Ein Freund ist ein Mensch,vor dem man laut denken kann.", 
  "Menschen,die nicht an sich selbst glauben,k�nnen anderen keinen Halt geben.", 
  "Wenn man seine Ruhe,nicht in sich findet,ist es zwecklos,sie anderswo zu suchen.",
  "An dem Tag,an dem du zu reisen aufh�rst,wirst du angekommen sein", 
  "Die modernste Form,menschlicher Armut,ist das Keine-Zeit-Haben.", 
  "ZEIT ist keine Schnellstra�e,zwischen Wiege und Grab,sondern Platz zum Parken,in der SONNE.", 
  "Der Zufall ist der,gebr�uchlichste Deckname,von Gottes Plan.", 
  "Es ist moralisch notwendig,das Dasein Gottes anzunehmen.", 
  "Auge um Auge,bedeutet nur,dass die Welt erblindet.",
  "Der Mensch ist nichts anderes,als wozu er sich macht!", 
  "Die Sch�nheit der Dinge,lebt in der Seele dessen,der sie betrachtet.", 
  "Du kannst dem Leben,nicht mehr Tage geben,aber dem Tag mehr Leben.", 
  "Wege entstehen dadurch,da� man sie geht.", 
  "Wende Dich stets,der Sonne zu,dann fallen die Schatten,hinter Dich.", 
  "Gl�ck bedeutet nicht,das zu kriegen,was wir wollen,sondern das zu wollen,was wir kriegen.", 
  "Phantasie ist wichtiger,als Wissen,denn Wissen ist begrenzt.", 
  "Gib jedem Tag die Chance,der sch�nste,deines Lebens zu werden.", 
  "Nicht der ist ein Verlierer,der hinf�llt,sondern der,der liegenbleibt.", 
  "Man kann dir den Weg weisen,gehen musst du ihn selbst.", 
  "Eine schmerzliche Wahrheit,ist besser als eine L�ge.", 
  "Selbst eine Reise,von tausend Meilen,beginnt mit dem ersten Schritt.", 
  "Wer einen Fehler macht,und ihn nicht korrigiert,begeht einen zweiten.", 
  "Die Menschen verlieren,die meiste Zeit damit,dass sie Zeit gewinnen wollen.", 
  "Ein Tag ohne zu L�cheln,ist ein verlorener Tag!", 
  "Das Gl�ck ist das einzige,was sich verdoppelt,wenn man es teilt.", 
  "Jede Roheit hat ihren Ursprung,in einer Schw�che.", 
  "Kinder die man nicht liebt,werden Erwachsene,die nicht lieben.", 
  "Ich kann die Welt,nicht ver�ndern,aber einen einzelnen Menschen:,mich selbst.", 
  "Der Optimist,sieht in jedem Problem,eine Aufgabe.,Der Pessimist,sieht in jeder Aufgabe,ein Problem.", 
  "Der beste Weg,einen schlechten Vorschlag,vom Tisch zu wischen,besteht darin,einen Besseren zu machen.", 
  "Nicht die Jahre,in unserem Leben z�hlen,sondern das Leben,in unseren Jahren z�hlt.", 
  "Gib mir Gelassenheit,Dinge hinzunehmen,die ich nicht �ndern kann,gib mir den Mut,Dinge zu �ndern,die ich �ndern kann,und gib mir die Weisheit,das eine vom anderen,zu unterscheiden.", 
  "Die Grenzen des M�glichen,lassen sich nur,dadurch bestimmen,da� man sich ein wenig,�ber sie hinaus,ins Unm�gliche wagt.", 
  "Tritt nicht in die Fu�stapfen anderer,du hinterl��t sonst selbst keine Spuren.", 
  "Weine nicht,weil es vorbei ist,sondern lache,weil es so sch�n war.", 
  "Mitleid bekommt man geschenkt,Neid muss man sich hart erarbeiten.", 
  "Wenn jemand sagt,er habe keine Zeit,bedeutet das nur,da� andere Dinge wichtiger f�r ihn sind.", 
  "Wenn Du immer nur das tust,was Du bereits kannst,bleibst Du immer nur das,was Du heute bist!", 
  "Erfolg besteht darin,dass man genau die,F�higkeiten hat,die im Moment gefragt sind.", 
  "Ideale sind wie Sterne,wir erreichen sie niemals,aber wie die Seefahrer,auf dem Meer,k�nnen wir unseren Kurs,nach ihnen richten.", 
  "Wenn wir nicht immer wieder,etwas Neues probiert h�tten,w�rden wir heute noch,in H�hlen leben.", 
  "", 
  ""
  };
 
  return( which>0 && which<=MAX?Sentence[which]:Sentence[0] );
}


EVENT OnClick(EventPtr event)
{
   // Return "false" to execute default message handling
   char tmp[1000];
   int i;
   i = SysRandom(0)%MAX;  // any of the MAX sentences
   StrCopy(tmp, Sentences(i) );
   ListBox1.Erase;
   ListBox1.Items=tmp;
   ListBox1.Draw; 
   return true;
}

EVENT DoExit(EventPtr event)
{
   // Return "false" to execute default message handling
   philo.Terminate();

}

EVENT ShowForm2(EventPtr event)
{
   // Return "false" to execute default message handling
   Form2.PopUp();
}
