#include <PalmOS.h>
#include <C:\palmphi\my\philo\philo.h>

#define EVENT int
EventPtr __evt;
#define StrToInt(x) StrAToI(x)
#define FIELDTYPE_STRING 0
#define FIELDTYPE_INTEGER 1
#define StrToInt(x) StrAToI(x)
enum _BorderStyles {bsNone,bsSingle,bsBold};
typedef struct {
    Char Visible,Border;
    UInt16 Left,Top,Width,Height;
    UInt16 *ids;
    UInt32 color;
} PanelType;
typedef struct {
    DmOpenRef bd;
    UInt16 cat;
} PalmDBType;
char StopEvent=0,EditAutoDraw=1;
#define Button1_top 25
#define Button1_left 10
#define Button1_width 45
#define Button1_height 15
#define Button2_top 25
#define Button2_left 100
#define Button2_width 45
#define Button2_height 15
#define Button3_top 115
#define Button3_left 59
#define Button3_width 40
#define Button3_height 15
#define Button4_top 25
#define Button4_left 60
#define Button4_width 35
#define Button4_height 15
#define Form1_top 0
#define Form1_left 0
#define Form1_width 160
#define Form1_height 160
#define Form2_top 0
#define Form2_left 0
#define Form2_width 160
#define Form2_height 160
#define Label1_top 36
#define Label1_left 15
#define Label1_width 127
#define Label1_height 11
#define Label2_top 54
#define Label2_left 15
#define Label2_width 107
#define Label2_height 11
#define Label3_top 75
#define Label3_left 15
#define Label3_width 108
#define Label3_height 11
#define ListBox1_top 45
#define ListBox1_left 10
#define ListBox1_width 135
#define ListBox1_height 95
register void *reg_a4 asm("%a4");
#define CALLBACK_PROLOGUE void *save_a4 = reg_a4; asm("move.l %%a5,%%a4; sub.l #edata,%%a4" : :);
#define CALLBACK_EPILOGUE reg_a4 = save_a4;

#define ListBox1_num 0
MemHandle _ListHandles[1];
Char* _ListStrings[1];

// Definition of Function : Screen_EraseRect
void Screen_EraseRect(Int16 x1,Int16 y1,Int16 x2,Int16 y2)
{
   RectangleType  bounds;
   bounds.topLeft.x=x1;
   bounds.topLeft.y=y1;
   bounds.extent.x=x2-x1;
   bounds.extent.y=y2-y1;
   WinEraseRectangle(&bounds, 0);
}

// Definition of Function : LIST_SetListItem
void LIST_SetListItem(Char **ListItems,MemHandle *ListHandle,ListPtr list,Char* str)
{
   Int16 n=1;
   if (*ListItems) {
      MemPtrFree(*ListItems);
      MemHandleUnlock(*ListHandle);
      MemHandleFree(*ListHandle);
   }
   *ListItems=MemPtrNew(StrLen(str)+1);
   StrCopy(*ListItems,str);
   str=*ListItems;
   while (1) {
      if (!*str) break;
      if (*str==',') {
         *str='\0';
         n++;
      }
      str++;
   }
   str=*ListItems;
   *ListHandle=SysFormPointerArrayToStrings(str, n);
   LstSetListChoices(list, 0, 0);
   LstSetListChoices(list, MemHandleLock(*ListHandle), n);
}

// Definition of Function : Application_Terminate
void Application_Terminate() {
	EventType	newEvent;
	MemSet(&newEvent, sizeof(EventType), 0);
   	newEvent.eType = appStopEvent;
   	EvtAddEventToQueue(&newEvent);
}
ControlPtr Button1;
EVENT OnClick(EventPtr event) ;
ControlPtr Button2;
EVENT DoExit(EventPtr event) ;
ControlPtr Button3;
EVENT GotoForm1(EventPtr event) ;
ControlPtr Button4;
EVENT ShowForm2(EventPtr event) ;
FormPtr Form1;
FormPtr Form2;



ListPtr ListBox1;

Err StartApplication(void)
{
{
   int i;for(i=0;i<1;i++) {_ListHandles[i]=0;_ListStrings[i]=0;}}
    FrmGotoForm(_Form1);
    return 0;
}

void StopApplication(void)
{
    if (EditAutoDraw == EditAutoDraw) {} 
	FrmSaveAllForms();
{int i;for(i=0;i<1;i++) {
 if (_ListStrings[i]) {
MemPtrFree(_ListStrings[i]);
MemHandleUnlock(_ListHandles[i]);
MemHandleFree(_ListHandles[i]);
}
}}
	FrmCloseAllForms();
}


Boolean Form1_EventHandler(EventPtr event)
{
    Boolean handled = false;
    CALLBACK_PROLOGUE
    __evt=event;
    Form1=FrmGetFormPtr(_Form1);
    Button1=FrmGetObjectPtr(Form1,FrmGetObjectIndex(Form1,_Button1));
    ListBox1=FrmGetObjectPtr(Form1,FrmGetObjectIndex(Form1,_ListBox1));
    Button2=FrmGetObjectPtr(Form1,FrmGetObjectIndex(Form1,_Button2));
    Button4=FrmGetObjectPtr(Form1,FrmGetObjectIndex(Form1,_Button4));
    switch(event->eType) {

        case ctlSelectEvent:
            if (event->data.ctlSelect.controlID == _Button1)  {           OnClick(event);
            handled=true;
            }
            if (event->data.ctlSelect.controlID == _Button2)  {           DoExit(event);
            handled=true;
            }
            if (event->data.ctlSelect.controlID == _Button4)  {           ShowForm2(event);
            handled=true;
            }
            break;
        case ctlRepeatEvent:
            break;
        case penDownEvent:
        {
            break;
        }
        case penUpEvent:
        {
            break;
        }
        case frmUpdateEvent:
        {
              FrmHandleEvent(Form1,event);
               handled=true;
            break;
        }
        case penMoveEvent:
        {
            break;
        }
        case tblSelectEvent:
            break;
        case lstSelectEvent:
            break;
        case popSelectEvent:
            break;
        case fldEnterEvent:
            break;
        case sclRepeatEvent:
            break;
        case sclExitEvent:
            break;
        case frmOpenEvent:
           {
           }
           FrmDrawForm(Form1);
           handled = true;
           break;
        case frmSaveEvent:
           break;
        case frmCloseEvent:
           break;
       default:
           break;
    }
    CALLBACK_EPILOGUE
    return handled;
}

Boolean Form2_EventHandler(EventPtr event)
{
    Boolean handled = false;
    CALLBACK_PROLOGUE
    __evt=event;
    Form2=FrmGetFormPtr(_Form2);
    Button3=FrmGetObjectPtr(Form2,FrmGetObjectIndex(Form2,_Button3));
    switch(event->eType) {

        case ctlSelectEvent:
            if (event->data.ctlSelect.controlID == _Button3)  {           GotoForm1(event);
            handled=true;
            }
            break;
        case ctlRepeatEvent:
            break;
        case penDownEvent:
        {
            break;
        }
        case penUpEvent:
        {
            break;
        }
        case frmUpdateEvent:
        {
              FrmHandleEvent(Form2,event);
               handled=true;
            break;
        }
        case penMoveEvent:
        {
            break;
        }
        case tblSelectEvent:
            break;
        case lstSelectEvent:
            break;
        case popSelectEvent:
            break;
        case fldEnterEvent:
            break;
        case sclRepeatEvent:
            break;
        case sclExitEvent:
            break;
        case frmOpenEvent:
           {
           }
           FrmDrawForm(Form2);
           handled = true;
           break;
        case frmSaveEvent:
           break;
        case frmCloseEvent:
           break;
       default:
           break;
    }
    CALLBACK_EPILOGUE
    return handled;
}
Boolean Application_EventHandler(EventPtr event)
{
    FormPtr frm;
    int     formId;
    Boolean handled = false;

    switch (event->eType) {
       case frmLoadEvent : 
       {
           formId = event->data.frmLoad.formID;
           frm = FrmInitForm(formId);
           FrmSetActiveForm(frm);
                         
           switch(formId) {
                        
               case _Form1:
                   FrmSetEventHandler(frm, Form1_EventHandler);
                   break;
                
               case _Form2:
                   FrmSetEventHandler(frm, Form2_EventHandler);
                   break;
                
           }
           handled = true;
       }
       case menuEvent : 
       {
            switch (event->data.menu.itemID) {
            }
            handled = true;
       }
       default:
           break;
    }
    return handled;
}
void EventLoop(void)
{
    EventType event;
    UInt16 error;

    do {
        if(!StopEvent)
           EvtGetEvent(&event, evtWaitForever);
        if (! SysHandleEvent(&event))
            if (! MenuHandleEvent(0, &event, &error))
                if (! Application_EventHandler(&event))
                   FrmDispatchEvent(&event);
        } while (event.eType != appStopEvent && !StopEvent);
}

UInt32 PilotMain(UInt16 launchCode, MemPtr cmdPBP, UInt16 launchFlags)
{

    Err err;
    if (launchCode == sysAppLaunchCmdNormalLaunch) {
        if ((err = StartApplication()) == 0) {
            EventLoop();
            StopApplication();
        }
    }
    return 0;
}

#define MAX 51
                                                                                #line 2 "Form1.c"
Char *Sentences(UInt16 which)
                                                                                #line 3 "Form1.c"
{
                                                                                #line 4 "Form1.c"
 static Char *Sentence[]={ 
                                                                                #line 5 "Form1.c"
  "Der der ich bin,gr��t traurig den,der ich sein m�chte.", 
                                                                                #line 6 "Form1.c"
  "Der Idealismus w�chst,mit der Entfernung,vom Problem.", 
                                                                                #line 7 "Form1.c"
  "Fernsehen unterh�lt die Leute,indem es verhindert,da� sie sich unterhalten.", 
                                                                                #line 8 "Form1.c"
  "Ein Plan,der sich nicht �ndern l�sst,ist ein schlechter Plan.", 
                                                                                #line 9 "Form1.c"
  "Fehler die wir einsehen,k�nnen nicht mehr,ins Auge gehen.",
                                                                                #line 10 "Form1.c"
  "Der Vorteil der Klugheit,besteht darin,da� man sich dumm,stellen kann.,Das Gegenteil ist,schon schwieriger.", 
                                                                                #line 11 "Form1.c"
  "Eine Familie ist ein,steuerlich beg�nstigter,Kleinbetrieb,zur Herstellung von,Steuerzahlern.",
                                                                                #line 12 "Form1.c"
  "Tr�ume nicht dein Leben,lebe deinen Traum.", 
                                                                                #line 13 "Form1.c"
  "Wer keinen Mut,zum Tr�umen hat,hat keine Kraft,zum K�mpfen. ", 
                                                                                #line 14 "Form1.c"
  "In Dir muss brennen,was Du in anderen,entz�nden m�chtest.", 
                                                                                #line 15 "Form1.c"
  "Ein Freund ist ein Mensch,vor dem man laut denken kann.", 
                                                                                #line 16 "Form1.c"
  "Menschen,die nicht an sich selbst glauben,k�nnen anderen keinen Halt geben.", 
                                                                                #line 17 "Form1.c"
  "Wenn man seine Ruhe,nicht in sich findet,ist es zwecklos,sie anderswo zu suchen.",
                                                                                #line 18 "Form1.c"
  "An dem Tag,an dem du zu reisen aufh�rst,wirst du angekommen sein", 
                                                                                #line 19 "Form1.c"
  "Die modernste Form,menschlicher Armut,ist das Keine-Zeit-Haben.", 
                                                                                #line 20 "Form1.c"
  "ZEIT ist keine Schnellstra�e,zwischen Wiege und Grab,sondern Platz zum Parken,in der SONNE.", 
                                                                                #line 21 "Form1.c"
  "Der Zufall ist der,gebr�uchlichste Deckname,von Gottes Plan.", 
                                                                                #line 22 "Form1.c"
  "Es ist moralisch notwendig,das Dasein Gottes anzunehmen.", 
                                                                                #line 23 "Form1.c"
  "Auge um Auge,bedeutet nur,dass die Welt erblindet.",
                                                                                #line 24 "Form1.c"
  "Der Mensch ist nichts anderes,als wozu er sich macht!", 
                                                                                #line 25 "Form1.c"
  "Die Sch�nheit der Dinge,lebt in der Seele dessen,der sie betrachtet.", 
                                                                                #line 26 "Form1.c"
  "Du kannst dem Leben,nicht mehr Tage geben,aber dem Tag mehr Leben.", 
                                                                                #line 27 "Form1.c"
  "Wege entstehen dadurch,da� man sie geht.", 
                                                                                #line 28 "Form1.c"
  "Wende Dich stets,der Sonne zu,dann fallen die Schatten,hinter Dich.", 
                                                                                #line 29 "Form1.c"
  "Gl�ck bedeutet nicht,das zu kriegen,was wir wollen,sondern das zu wollen,was wir kriegen.", 
                                                                                #line 30 "Form1.c"
  "Phantasie ist wichtiger,als Wissen,denn Wissen ist begrenzt.", 
                                                                                #line 31 "Form1.c"
  "Gib jedem Tag die Chance,der sch�nste,deines Lebens zu werden.", 
                                                                                #line 32 "Form1.c"
  "Nicht der ist ein Verlierer,der hinf�llt,sondern der,der liegenbleibt.", 
                                                                                #line 33 "Form1.c"
  "Man kann dir den Weg weisen,gehen musst du ihn selbst.", 
                                                                                #line 34 "Form1.c"
  "Eine schmerzliche Wahrheit,ist besser als eine L�ge.", 
                                                                                #line 35 "Form1.c"
  "Selbst eine Reise,von tausend Meilen,beginnt mit dem ersten Schritt.", 
                                                                                #line 36 "Form1.c"
  "Wer einen Fehler macht,und ihn nicht korrigiert,begeht einen zweiten.", 
                                                                                #line 37 "Form1.c"
  "Die Menschen verlieren,die meiste Zeit damit,dass sie Zeit gewinnen wollen.", 
                                                                                #line 38 "Form1.c"
  "Ein Tag ohne zu L�cheln,ist ein verlorener Tag!", 
                                                                                #line 39 "Form1.c"
  "Das Gl�ck ist das einzige,was sich verdoppelt,wenn man es teilt.", 
                                                                                #line 40 "Form1.c"
  "Jede Roheit hat ihren Ursprung,in einer Schw�che.", 
                                                                                #line 41 "Form1.c"
  "Kinder die man nicht liebt,werden Erwachsene,die nicht lieben.", 
                                                                                #line 42 "Form1.c"
  "Ich kann die Welt,nicht ver�ndern,aber einen einzelnen Menschen:,mich selbst.", 
                                                                                #line 43 "Form1.c"
  "Der Optimist,sieht in jedem Problem,eine Aufgabe.,Der Pessimist,sieht in jeder Aufgabe,ein Problem.", 
                                                                                #line 44 "Form1.c"
  "Der beste Weg,einen schlechten Vorschlag,vom Tisch zu wischen,besteht darin,einen Besseren zu machen.", 
                                                                                #line 45 "Form1.c"
  "Nicht die Jahre,in unserem Leben z�hlen,sondern das Leben,in unseren Jahren z�hlt.", 
                                                                                #line 46 "Form1.c"
  "Gib mir Gelassenheit,Dinge hinzunehmen,die ich nicht �ndern kann,gib mir den Mut,Dinge zu �ndern,die ich �ndern kann,und gib mir die Weisheit,das eine vom anderen,zu unterscheiden.", 
                                                                                #line 47 "Form1.c"
  "Die Grenzen des M�glichen,lassen sich nur,dadurch bestimmen,da� man sich ein wenig,�ber sie hinaus,ins Unm�gliche wagt.", 
                                                                                #line 48 "Form1.c"
  "Tritt nicht in die Fu�stapfen anderer,du hinterl��t sonst selbst keine Spuren.", 
                                                                                #line 49 "Form1.c"
  "Weine nicht,weil es vorbei ist,sondern lache,weil es so sch�n war.", 
                                                                                #line 50 "Form1.c"
  "Mitleid bekommt man geschenkt,Neid muss man sich hart erarbeiten.", 
                                                                                #line 51 "Form1.c"
  "Wenn jemand sagt,er habe keine Zeit,bedeutet das nur,da� andere Dinge wichtiger f�r ihn sind.", 
                                                                                #line 52 "Form1.c"
  "Wenn Du immer nur das tust,was Du bereits kannst,bleibst Du immer nur das,was Du heute bist!", 
                                                                                #line 53 "Form1.c"
  "Erfolg besteht darin,dass man genau die,F�higkeiten hat,die im Moment gefragt sind.", 
                                                                                #line 54 "Form1.c"
  "Ideale sind wie Sterne,wir erreichen sie niemals,aber wie die Seefahrer,auf dem Meer,k�nnen wir unseren Kurs,nach ihnen richten.", 
                                                                                #line 55 "Form1.c"
  "Wenn wir nicht immer wieder,etwas Neues probiert h�tten,w�rden wir heute noch,in H�hlen leben.", 
                                                                                #line 56 "Form1.c"
  "", 
                                                                                #line 57 "Form1.c"
  ""
                                                                                #line 58 "Form1.c"
  };
                                                                                #line 59 "Form1.c"
 
                                                                                #line 60 "Form1.c"
  return( which>0 && which<=MAX?Sentence[which]:Sentence[0] );
                                                                                #line 61 "Form1.c"
}
                                                                                #line 62 "Form1.c"

                                                                                #line 63 "Form1.c"

                                                                                #line 64 "Form1.c"
EVENT OnClick(EventPtr event)
                                                                                #line 65 "Form1.c"
{
                                                                                #line 66 "Form1.c"
   
                                                                                #line 67 "Form1.c"
   char tmp[1000];
                                                                                #line 68 "Form1.c"
   int i;
                                                                                #line 69 "Form1.c"
   i = SysRandom(0)%MAX;  
                                                                                #line 70 "Form1.c"
   StrCopy(tmp, Sentences(i) );
                                                                                #line 71 "Form1.c"
Screen_EraseRect(ListBox1_left,ListBox1_top,ListBox1_left+ListBox1_width,ListBox1_top+ListBox1_height);
                                                                                #line 72 "Form1.c"
LIST_SetListItem(&_ListStrings[ListBox1_num],&_ListHandles[ListBox1_num],ListBox1,tmp);
                                                                                #line 73 "Form1.c"
LstDrawList(ListBox1);
                                                                                #line 74 "Form1.c"
   return true;
                                                                                #line 75 "Form1.c"
}
                                                                                #line 76 "Form1.c"

                                                                                #line 77 "Form1.c"
EVENT DoExit(EventPtr event)
                                                                                #line 78 "Form1.c"
{
                                                                                #line 79 "Form1.c"
   
                                                                                #line 80 "Form1.c"
Application_Terminate();
                                                                                #line 81 "Form1.c"

                                                                                #line 82 "Form1.c"
}
                                                                                #line 83 "Form1.c"

                                                                                #line 84 "Form1.c"
EVENT ShowForm2(EventPtr event)
                                                                                #line 85 "Form1.c"
{
                                                                                #line 86 "Form1.c"
   
                                                                                #line 87 "Form1.c"
FrmPopupForm(_Form2);
                                                                                #line 88 "Form1.c"
}
                                                                                #line 89 "Form1.c"

EVENT GotoForm1(EventPtr event)
                                                                                #line 2 "Form2.c"
{
                                                                                #line 3 "Form2.c"
   
                                                                                #line 4 "Form2.c"
FrmReturnToForm(0);
                                                                                #line 5 "Form2.c"
}
