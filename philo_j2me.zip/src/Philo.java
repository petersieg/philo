/*
 * Philo.java
 *
 * written 2006 Peter.Sieg@gmx.de
 * 
 */

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.util.*;

/**
 * This demo is based on the HelloMIDlet template. It shows
 * a PNG image and some philosphical sayings
 */
public class Philo extends MIDlet implements CommandListener {
    
    private Command enterCommand; // The enter command
    private Command exitCommand; // The exit command
    private Display display;    // The display for this MIDlet
    private Form firstScreen;
    private Ticker t;
    private Random random;
    private int n;
    static final int MAXSAY = 52;
    static final String [] SAY = {   
  "Der der ich bin,gruesst traurig den,der ich sein moechte.",
  "Der Idealismus waechst,mit der Entfernung,vom Problem.",
  "Fernsehen unterhaelt die Leute,indem es verhindert,dass sie sich unterhalten.",
  "Ein Plan,der sich nicht aendern laesst,ist ein schlechter Plan.",
  "Fehler die wir einsehen,koennen nicht mehr,ins Auge gehen.",
  "Der Vorteil der Klugheit,besteht darin,dass man sich dumm,stellen kann.,Das Gegenteil ist,schon schwieriger.",
  "Eine Familie ist ein,steuerlich beguenstigter,Kleinbetrieb,zur Herstellung von,Steuerzahlern.",
  "Traeume nicht dein Leben,lebe deinen Traum.",
  "Wer keinen Mut,zum Traeumen hat,hat keine Kraft,zum Kaempfen.",
  "In Dir muss brennen,was Du in anderen,entzuenden moechtest.",
  "Ein Freund ist ein Mensch,vor dem man laut denken kann.",
  "Menschen,die nicht an sich selbst glauben,koennen anderen keinen Halt geben.",
  "Wenn man seine Ruhe,nicht in sich findet,ist es zwecklos,sie anderswo zu suchen.",
  "An dem Tag,an dem du zu reisen aufhoerst,wirst du angekommen sein.",
  "Die modernste Form,menschlicher Armut,ist das Keine-Zeit-Haben.",
  "ZEIT ist keine Schnellstrasse,zwischen Wiege und Grab,sondern Platz zum Parken,in der SONNE.",
  "Der Zufall ist der,gebraeuchlichste Deckname,von Gottes Plan.",
  "Es ist moralisch notwendig,das Dasein Gottes anzunehmen.",
  "Auge um Auge,bedeutet nur,dass die Welt erblindet.",
  "Der Mensch ist nichts anderes,als wozu er sich macht.",
  "Die Schoenheit der Dinge,lebt in der Seele dessen,der sie betrachtet.",
  "Du kannst dem Leben,nicht mehr Tage geben,aber dem Tag mehr Leben.",
  "Wege entstehen dadurch,dass man sie geht.",
  "Wende Dich stets,der Sonne zu,dann fallen die Schatten,hinter Dich.",
  "Glueck bedeutet nicht,das zu kriegen,was wir wollen,sondern das zu wollen,was wir kriegen.",
  "Phantasie ist wichtiger,als Wissen,denn Wissen ist begrenzt.",
  "Gib jedem Tag die Chance,der schoenste,deines Lebens zu werden.",
  "Nicht der ist ein Verlierer,der hinfaellt,sondern der,der liegenbleibt.",
  "Man kann dir den Weg weisen,gehen musst du ihn selbst.",
  "Eine schmerzliche Wahrheit,ist besser als eine Luege.",
  "Selbst eine Reise,von tausend Meilen,beginnt mit dem ersten Schritt.",
  "Wer einen Fehler macht,und ihn nicht korrigiert,begeht einen zweiten.",
  "Die Menschen verlieren,die meiste Zeit damit,dass sie Zeit gewinnen wollen.",
  "Ein Tag ohne zu Laecheln,ist ein verlorener Tag.",
  "Das Glueck ist das einzige,was sich verdoppelt,wenn man es teilt.",
  "Jede Roheit hat ihren Ursprung,in einer Schwaeche.",
  "Kinder die man nicht liebt,werden Erwachsene,die nicht lieben.",
  "Ich kann die Welt,nicht veraendern,aber einen einzelnen Menschen: mich selbst.",
  "Der Optimist,sieht in jedem Problem,eine Aufgabe. Der Pessimist,sieht in jeder Aufgabe,ein Problem.",
  "Der beste Weg,einen schlechten Vorschlag,vom Tisch zu wischen,besteht darin,einen Besseren zu machen.",
  "Nicht die Jahre,in unserem Leben zaehlen,sondern das Leben,in unseren Jahren zaehlt.",
  "Gib mir Gelassenheit,Dinge hinzunehmen,die ich nicht aendern kann,gib mir den Mut,Dinge zu aendern,die ich aendern kann,und gib mir die Weisheit,das eine vom anderen,zu unterscheiden.",
  "Die Grenzen des Moeglichen,lassen sich nur,dadurch bestimmen,dass man sich ein wenig,ueber sie hinaus,ins Unmoegliche wagt.",
  "Tritt nicht in die Fussstapfen anderer,du hinterlaesst sonst selbst keine Spuren.",
  "Weine nicht,weil es vorbei ist,sondern lache,weil es so schoen war.",
  "Mitleid bekommt man geschenkt,Neid muss man sich hart erarbeiten.",
  "Wenn jemand sagt,er habe keine Zeit,bedeutet das nur,dass andere Dinge wichtiger fuer ihn sind.",
  "Wenn Du immer nur das tust,was Du bereits kannst,bleibst Du immer nur das,was Du heute bist.",
  "Erfolg besteht darin,dass man genau die,Faehigkeiten hat,die im Moment gefragt sind.",
  "Ideale sind wie Sterne,wir erreichen sie niemals,aber wie die Seefahrer,auf dem Meer,koennen wir unseren Kurs,nach ihnen richten.",
  "Wenn wir nicht immer wieder,etwas Neues probiert haetten,wuerden wir heute noch,in Hoehlen leben."
  };  
    public Philo() {
        display = Display.getDisplay(this);
        enterCommand = new Command("Zeigs mir", Command.OK, 1);
        exitCommand = new Command("Exit", Command.EXIT, 1);
    }
    
    /**
     * Start up the Hello MIDlet
     */
    public void startApp() {
        /*
         * we define how the first screen looks like
         */
        firstScreen = new Form("Philo");
        try {
            Image ich = Image.createImage("/ich.png");
            firstScreen.append(ich);
        } catch (IOException e) {
        }
        t = new Ticker("Philosophische Spr�che... (c) 2006 Peter.Sieg@gmx.de");
        firstScreen.setTicker(t);
        firstScreen.addCommand(enterCommand);
        firstScreen.addCommand(exitCommand);
        firstScreen.setCommandListener(this);
        
        display.setCurrent(firstScreen);
        random = new java.util.Random();
    }
    
    /**
     * Pause is a no-op since there are no background activities or
     * record stores that need to be closed.
     */
    public void pauseApp() {
    }
    
    /**
     * Destroy must cleanup everything not handled by the garbage collector.
     * In this case there is nothing to cleanup.
     */
    public void destroyApp(boolean unconditional) {
    }
    
    /*
     * Respond to commands, including exit
     * On the exit command, cleanup and notify that the MIDlet has been destroyed.
     */
    public void commandAction(Command c, Displayable s) {
        if (c == exitCommand) {
            destroyApp(false);
            notifyDestroyed();
        }
        else if (c == enterCommand) {
            n = (random.nextInt() >>> 1) % MAXSAY;
            t.setString(SAY[n]);
        }
    }
    
}
