forked from [jmk/cc65-nes-examples](https://github.com/jmk/cc65-nes-examples)
updated for cc65 2.13.9
tested on Ubuntu

