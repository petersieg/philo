//this example code shows how to put some text in nametable
//it assumes that you have ASCII-encoded font in the CHR tiles $00-$3f

#include "neslib.h"


//this macro is used remove need of calculation of the nametable address in runtime

#define NTADR(x,y) ((0x2000|((y)<<5)|x))


//put a string into the nametable

void put_str(unsigned int adr,const char *str)
{
	vram_adr(adr);

	while(1)
	{
		if(!*str) break;
		vram_put((*str++)-0x20);//-0x20 because ASCII code 0x20 is placed in tile 0 of the CHR
	}
}


void main(void)
{
	unsigned int msg = 0,i = 0,n = 0;
	//rendering is disabled at the startup, and palette is all black

	//pal_col(1,0x30);//set while color

	while(i == 0)
	{
		n++;
		//poll the pad to set rand to a random value
		i=pad_poll(0);
	}
	set_rand(n);
	
	while(1)
	{

	pal_col(1,rand8()%16+32);	//set color
	
	msg = rand8()%25+1;	//select text message
	
	//you can't put data into vram through vram_put while rendering is enabled
	//so you have to disable rendering to put things like text or a level map
	//into the nametable

	//there is a way to update small number of nametable tiles while rendering
	//is enabled, using set_vram_update and an update list

	if (msg <= 1) { 
	put_str(NTADR(2,4),"TRAEUME NICHT DEIN LEBEN");
	put_str(NTADR(2,6),"LEBE DEINEN TRAUM.");
	}
 
	if (msg == 2) { 
	put_str(NTADR(2,4),"SELBST EINE REISE");
	put_str(NTADR(2,6),"VON TAUSEND MEILEN");
	put_str(NTADR(2,8),"BEGINT MIT DEM");
	put_str(NTADR(2,10),"ERSTEN SCHRITT.");
	}
 
	if (msg == 3) { 
	put_str(NTADR(2,4),"TRITT NICHT IN DIE FUSS-");
 	put_str(NTADR(2,6),"STAPFEN ANDERER");
	put_str(NTADR(2,8),"DU HINTERLAEST SONST");
	put_str(NTADR(2,10),"SELBST KEINE SPUREN.");
	}
 
	if (msg == 4) { 
	put_str(NTADR(2,4),"AUGE UM AUGE");
	put_str(NTADR(2,6),"BEDEUTET NUR");
	put_str(NTADR(2,8),"DASS DIE WELT");
	put_str(NTADR(2,10),"ERBLINDET.");
	}
 
	if (msg == 5) { 
	put_str(NTADR(2,4),"DER IDEALISMUS");
	put_str(NTADR(2,6),"WAECHST");
	put_str(NTADR(2,8),"MIT DER ENTFERNUNG");
	put_str(NTADR(2,10),"VOM PROBLEM.");
	}
 
	if (msg == 6) { 
	put_str(NTADR(2,4),"PHANTASIE IST WICHTIGER");
	put_str(NTADR(2,6),"ALS WISSEN");
	put_str(NTADR(2,8),"DENN WISSEN IST BEGRENZT.");
	}
 
	if (msg == 7) { 
	put_str(NTADR(2,4),"WER KEINEN MUT");
	put_str(NTADR(2,6),"ZUM TRAEUMEN HAT");
	put_str(NTADR(2,8),"HAT KEINE KRAFT");
	put_str(NTADR(2,10),"ZUM KAEMPFEN.");
	}
 
	if (msg == 8) { 
	put_str(NTADR(2,4),"DER DER ICH BIN");
	put_str(NTADR(2,6),"GRUESST TRAURIG DEN");
	put_str(NTADR(2,8),"DER ICH SEIN MOECHTE.");
	}
 
	if (msg == 9) { 
	put_str(NTADR(2,4),"FEHLER DIE WIR EINSEHEN");
	put_str(NTADR(2,6),"KOENNEN NICHT MEHR");
	put_str(NTADR(2,8),"INS AUGE GEHEN.");
	}
 
	if (msg == 10) { 
	put_str(NTADR(2,4),"IN DIR MUSS BRENNEN");
	put_str(NTADR(2,6),"WAS DU IN ANDEREN");
	put_str(NTADR(2,8),"ENTZUENDEN MOECHTEST.");
	}
 
	if (msg == 11) { 
	put_str(NTADR(2,4),"DIE GRENZEN DES MOEGLICHEN");
 	put_str(NTADR(2,6),"LASSEN SICH NUR DADURCH");
	put_str(NTADR(2,8),"BESTIMMEN, DAS MAN SICH");
	put_str(NTADR(2,10),"EIN WENIG UEBER SIE HINAUS");
	put_str(NTADR(2,12),"INS UNMOEGLICHE WAGT.");
	}
 
	if (msg == 12) { 
	put_str(NTADR(2,4),"MENSCHEN DIE NICHT");
	put_str(NTADR(2,6),"AN SICH SELBST GLAUBEN");
	put_str(NTADR(2,8),"KOENNEN ANDEREN");
	put_str(NTADR(2,10),"KEINEN HALT GEBEN.");
	}
 
	if (msg == 13) { 
	put_str(NTADR(2,4),"AN DEM TAG AN DEM DU");
	put_str(NTADR(2,6),"ZU REISEN AUFHOERST");
	put_str(NTADR(2,8),"WIRST DU ANGEKOMMEN SEIN.");
	}
 
	if (msg == 14) { 
	put_str(NTADR(2,4),"DIE MODERNSTE FORM");
	put_str(NTADR(2,6),"MENSCHLICHER ARMUT");
	put_str(NTADR(2,8),"IST DAS KEINE-ZEIT-HABEN.");
	}
 
	if (msg == 15) { 
	put_str(NTADR(2,4),"WENN DU IMMER NUR DAS TUST");
	put_str(NTADR(2,6),"WAS DU BEREITS KANNST");
	put_str(NTADR(2,8),"BLEIBST DU IMMER NUR DAS");
	put_str(NTADR(2,10),"WAS DU HEUTE BIST.");
	}

	if (msg == 16) { 
  	put_str(NTADR(2,4),"EIN PLAN DER SICH");
  	put_str(NTADR(2,6),"NICHT AENDERN LAESST");
  	put_str(NTADR(2,8),"IST EIN SCHLECHTER PLAN");
	}

	if (msg == 17) { 
  	put_str(NTADR(2,4),"WENN MAN SEINE RUHE NICHT"); 
  	put_str(NTADR(2,6),"IN SICH FINDET IST ES ZWECKLOS"); 
  	put_str(NTADR(2,8),"SIE ANDERSWO ZU SUCHEN.");
	}

	if (msg == 18) { 
  	put_str(NTADR(2,4),"DER ZUFALL IST DER"); 
  	put_str(NTADR(2,6),"GEBRAEUCHLICHSTE DECKNAME");
  	put_str(NTADR(2,8),"VON GOTTES PLAN.");
	}

	if (msg == 19) { 
  	put_str(NTADR(2,4),"ES IST MORALISCH NOTWENDIG"); 
  	put_str(NTADR(2,6),"DAS DASEIN GOTTES ANZUNEHMEN.");
	}

	if (msg == 20) { 
  	put_str(NTADR(2,4),"DER MENSCH IST NICHTS ANDERES"); 
  	put_str(NTADR(2,6),"ALS WOZU ER SICH MACHT."); 
	}

	if (msg == 21) { 
  	put_str(NTADR(2,4),"DIE SCHOENHEIT DER DINGE"); 
  	put_str(NTADR(2,6),"LEBT IN DER SEELE DESSEN"); 
  	put_str(NTADR(2,8),"DER SIE BETRACHTET.");
	}

	if (msg == 22) { 
  	put_str(NTADR(2,4),"DU KANNST DEM LEBEN"); 
  	put_str(NTADR(2,6),"NICHT MEHR TAGE GEBEN"); 
  	put_str(NTADR(2,8),"ABER DEM TAG MEHR LEBEN.");
	}

	if (msg == 23) { 
  	put_str(NTADR(2,4),"WEGE ENTSTEHEN DADURCH"); 
  	put_str(NTADR(2,6),"DASS MAN SIE GEHT.");
	}

	if (msg == 24) { 
  	put_str(NTADR(2,4),"WENDE DICH STETS"); 
  	put_str(NTADR(2,6),"DER SONNE ZU DANN"); 
  	put_str(NTADR(2,8),"FALLEN DIE SCHATTEN"); 
  	put_str(NTADR(2,10),"HINTER DICH.");
	}

	if (msg == 25) { 
  	put_str(NTADR(2,4),"GLUECK BEDEUTET NICHT DAS"); 
  	put_str(NTADR(2,6),"ZU KRIEGEN WAS WIR WOLLEN"); 
  	put_str(NTADR(2,8),"SONDERN DAS ZU WOLLEN"); 
  	put_str(NTADR(2,10),"WAS WIR KRIEGEN."); 
	}

	if (msg >= 26) { 
  	put_str(NTADR(2,4),"GIB JEDEM TAG DIE CHANCE"); 
  	put_str(NTADR(2,6),"DER SCHOENSTE DEINES LEBENS"); 
  	put_str(NTADR(2,8),"ZU WERDEN.");
	}
  
  
  /* 
  "ZEIT IST KEINE SCHNELLSTRAFLE ZWISCHEN WIEGE UND GRAB SONDERN PLATZ ZUM PARKEN IN DER SONNE.", 
  "NICHT DER IST EIN VERLIERER,DER HINFAELLT,SONDERN DER,DER LIEGENBLEIBT.", 
  "MAN KANN DIR DEN WEG WEISEN,GEHEN MUSST DU IHN SELBST.",                                                                                
  "EINE SCHMERZLICHE WAHRHEIT,IST BESSER ALS EINE LUEGE.", 
  "WER EINEN FEHLER MACHT,UND IHN NICHT KORRIGIERT,BEGEHT EINEN ZWEITEN.",                                                                                
  "DIE MENSCHEN VERLIEREN,DIE MEISTE ZEIT DAMIT,DASS SIE ZEIT GEWINNEN WOLLEN.",                                                                                
  "EIN TAG OHNE ZU LAECHELN,IST EIN VERLORENER TAG",                                                                                
  "DAS GUECK IST DAS EINZIGE,WAS SICH VERDOPPELT,WENN MAN ES TEILT.", 
  "JEDE ROHEIT HAT IHREN URSPRUNG,IN EINER SCHWAECHE.", 
  "KINDER DIE MAN NICHT LIEBT,WERDEN ERWACHSENE,DIE NICHT LIEBEN.", 
  "ICH KANN DIE WELT,NICHT VERAENDERN,ABER EINEN EINZELNEN MENSCHEN: MICH SELBST.", 
  "DER OPTIMIST,SIEHT IN JEDEM PROBLEM,EINE AUFGABE. DER PESSIMIST,SIEHT IN JEDER AUFGABE,EIN PROBLEM.", 
  "DER BESTE WEG,EINEN SCHLECHTEN VORSCHLAG,VOM TISCH ZU WISCHEN,BESTEHT DARIN,EINEN BESSEREN ZU MACHEN.", 
  "NICHT DIE JAHRE,IN UNSEREM LEBEN ZAEHLEN,SONDERN DAS LEBEN,IN UNSEREN JAHREN ZAEHLT.", 
  "WEINE NICHT,WEIL ES VORBEI IST,SONDERN LACHE,WEIL ES SO SCHOEN WAR.", 
  "MITLEID BEKOMMT MAN GESCHENKT,NEID MUSS MAN SICH HART ERARBEITEN.", 
  "WENN JEMAND SAGT,ER HABE KEINE ZEIT,BEDEUTET DAS NUR,DAS ANDERE DINGE WICHTIGER FUER IHN SIND.",                                                                                
  "IDEALE SIND WIE STERNE,WIR ERREICHEN SIE NIEMALS,ABER WIE DIE SEEFAHRER,AUF DEM MEER,KOENNEN WIR UNSEREN KURS,NACH IHNEN RICHTEN.", 
  "WENN WIR NICHT IMMER WIEDER,ETWAS NEUES PROBIERT HAETTEN,WUERDEN WIR HEUTE NOCH,IN HOEHLEN LEBEN.", 
  "DER VORTEIL DER KLUGHEIT,BESTEHT DARIN,DAFL MAN SICH DUMM,STELLEN KANN.,DAS GEGENTEIL IST,SCHON SCHWIERIGER.", 
  "GIB MIR GELASSENHEIT,DINGE HINZUNEHMEN,DIE ICH NICHT AENDERN KANN,GIB MIR DEN MUT,DINGE ZU AENDERN,DIE ICH AENDERN KANN,UND GIB MIR DIE WEISHEIT,DAS EINE VOM ANDEREN,ZU UNTERSCHEIDEN.", 
  */
  
	ppu_on_all();//enable rendering

	delay(4000);
	delay(4000);
	
	ppu_off();
	/* Empty text screen */
	put_str(NTADR(2,4),"                              ");
 	put_str(NTADR(2,6),"                              ");
	put_str(NTADR(2,8),"                              ");
	put_str(NTADR(2,10),"                              ");
	put_str(NTADR(2,12),"                              ");
	}
}