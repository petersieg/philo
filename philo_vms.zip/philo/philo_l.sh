#/bin/bash

while :
do
n=$(($RANDOM % 20)) 
echo $n
cat $n.txt
# rem wait 30s
ping 127.0.0.1 -c 30 > nul
done
