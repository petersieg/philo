
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define MAXLINE 	42
//34567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
const char header[MAXLINE][100]={
"Der der ich bin, gruesst traurig den der ich sein moechte.",
"Der Idealismus waechst mit der Entfernung vom Problem.",
"Ein Plan der sich nicht aendern laesst, ist ein schlechter Plan.",
"Traeume nicht dein Leben, lebe deinen Traum.",
"Wer keinen Mut zum Traeumen hat, hat keine Kraft zum Kaempfen.",
"In Dir muss brennen, was Du in anderen entzuenden moechtest.",
"An dem Tag an dem du zu reisen aufhoerst, wirst du angekommen sein.",
"Auge um Auge bedeutet nur, dass die Welt erblindet.",
"Das Fernsehen unterhaelt die Leute, indem es verhindert, das sie sich miteinander unterhalten.",
"Fehler die wir einsehen koennen nicht mehr ins Auge gehen.",
"Der Vorteil der Klugheit ist, das man sich dumm stellen kann. Das Gegenteil ist schon schwieriger.",
"Eine Familie ist ein steuerlich beguenstigter Kleinbetrieb zur Herstellung von Steuerzahlern.",
"Ein Freund ist ein Mensch, vor dem man laut denken kann.",
"Menschen die nicht an sich selbst glauben, koennen anderen keinen Halt geben.",
"Wenn man seine Ruhe nicht in sich findet, ist es zwecklos, sie anderswo zu suchen.",
"Die modernste Form menschlicher Armut ist das Keine-Zeit-Haben.",
"ZEIT ist keine Schnellstrasse zwischen Wiege und Grab, sondern Platz zum Parken in der SONNE.",
"Der Zufall ist der gebraeuchlichste Deckname von Gottes Plan.",
"Es ist moralisch notwendig, das Dasein Gottes anzunehmen.",
"Auge um Auge bedeutet nur, dass die Welt erblindet.",
"Der Mensch ist nichts anderes, als wozu er sich macht!",
"Die Schoenheit der Dinge, lebt in der Seele dessen, der sie betrachtet.",
"Du kannst dem Leben nicht mehr Tage geben - aber dem Tag mehr Leben.",
"Wege entstehen dadurch, das man sie geht.",
"Wende Dich stets der Sonne zu, dann fallen die Schatten hinter Dich.",
"Glueck bedeutet nicht das zu kriegen was wir wollen, sondern das zu wollen was wir kriegen.",
"Phantasie ist wichtiger als Wissen, denn Wissen ist begrenzt.",
"Gib jedem Tag die Chance, der schoenste deines Lebens zu werden.",
"Nicht der ist ein Verlierer der hinfaellt, sondern der der liegen bleibt.",
"Man kann dir den Weg weisen, gehen musst du ihn selbst.",
"Eine schmerzliche Wahrheit ist besser als eine Luege.",
"Selbst eine Reise von tausend Meilen beginnt mit dem ersten Schritt.",
"Wer einen Fehler macht und ihn nicht korrigiert, begeht einen zweiten.",
"Die Menschen verlieren die meiste Zeit damit, dass sie Zeit gewinnen wollen.",
"Ein Tag ohne zu Laecheln ist ein verlorener Tag!",
"Das Glueck ist das einzige, was sich verdoppelt wenn man es teilt.",
"Jede Roheit hat ihren Ursprung in einer Schwaeche.",
"Kinder die man nicht liebt, werden Erwachsene, die nicht lieben.",
"Ich kann die Welt nicht veraendern, aber einen einzelnen Menschen: mich selbst."
};

int line = 0;

int main(int argc, char **argv) {

    //btx header
    printf("%c%c%c%c%c%c%c%c",0x1f,0x26,0x21,0x0c,0x1e,0x0a,0x48,0x1f);
    printf("%c%c%c%c%c%c",0x2f,0x42,0x94,0x86,0xa,0x0d);
    srand(time(NULL)); // randomize seed
    line = rand() % MAXLINE; 
    //printf("%i ",line);
    printf("%s",header[line]);
}
